

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import utility.JdbcConnection;

import dao.OperationsDao;
import dao.OperationsDaoImpl;

public class OperationsController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public OperationsController() 
    {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		String op = request.getParameter("op");
		String rid = request.getParameter("rid");
		String id = request.getParameter("id");
		String location = request.getParameter("location");
		String cid = request.getParameter("cid");
		String cap = request.getParameter("cap");
		String labid = request.getParameter("labid");
		String stat = request.getParameter("stat");
		Connection con = null;
		con = JdbcConnection.getConnection();
		OperationsDao od = new OperationsDaoImpl();
		if(op != null)
		{
			if(op.equals("add"))
			{
				response.sendRedirect("addlab.jsp");
			}
			else if(op.equals("rmv"))
			{
				response.sendRedirect("removelab.jsp");
			}
		}
		
		else if(rid != null && !rid.equals(""))
		{
			int rmvid = Integer.parseInt(rid);
			boolean flag = od.removelab(rmvid, con);
			JdbcConnection.closeConnection(con);
			if(flag)
			{
				pw.println("Deleted");
			}
			else
			{
				response.sendRedirect("errorpage.jsp");
			}
		}
		else if(id.equals("") || cap.equals(""))
		{
			response.sendRedirect("addlab.jsp");
		}
		else if(id != null && location != null && cid != null && cap != null)
		{
			int labid1 = Integer.parseInt(id);
			int loc_id = Integer.parseInt(location);
			int con_id = Integer.parseInt(cid);
			int capacity = Integer.parseInt(cap);
			boolean flag = od.addlab(labid1, loc_id, con_id, capacity, con);
			JdbcConnection.closeConnection(con);
			if(flag)
			{
				pw.println("Lab Added");
			}
			else
			{
				response.sendRedirect("errorpage.jsp");
			}
		}
		else if(labid.equals(""))
		{
			response.sendRedirect("ChangeStatus.jsp");
		}
		else if(labid != null)
		{
			int labid2 = Integer.parseInt(labid);
			boolean flag = od.changestat(labid2, stat, con);
			JdbcConnection.closeConnection(con);
			if(flag)
			{
				pw.println("Status Changed");
			}
			else
			{
				response.sendRedirect("errorpage.jsp");
			}
		}
	}
}
