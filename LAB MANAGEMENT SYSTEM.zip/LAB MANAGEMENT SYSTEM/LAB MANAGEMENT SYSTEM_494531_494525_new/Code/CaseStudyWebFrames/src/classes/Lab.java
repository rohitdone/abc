package classes;

public class Lab 
{
	private int labid;
	private String location;
	private String city;
	private String status;
	private int capacity;
	public Lab(int labid, String location,String city, String status, int capacity) {
		super();
		this.labid = labid;
		this.location = location;
		this.city = city;
		this.status = status;
		this.capacity = capacity;
	}
	public Lab() {
		super();
	}
	
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	@Override
	public String toString() {
		return "Lab [labid=" + labid + ", location=" + location + ", city="
				+ city + ", status=" + status + ", capacity=" + capacity + "]";
	}
	public int getLabid() {
		return labid;
	}
	public void setLabid(int labid) {
		this.labid = labid;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String locationid) {
		this.location = locationid;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getCapacity() {
		return capacity;
	}
	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}
	
	
}
