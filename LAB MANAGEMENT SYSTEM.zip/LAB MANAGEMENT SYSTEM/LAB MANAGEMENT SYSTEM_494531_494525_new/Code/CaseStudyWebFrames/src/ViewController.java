

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import utility.JdbcConnection;

import classes.Lab;
import dao.ViewDao;
import dao.ViewDaoImpl;

public class ViewController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public ViewController() 
    {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		String oper = request.getParameter("op");
		System.out.println(oper);
		String id = request.getParameter("id");
		System.out.println("id :"+id);
		String city = request.getParameter("city");
		System.out.println(city);
		String location = request.getParameter("location");
		System.out.println(location);
		String status = request.getParameter("status");
		System.out.println(status);
		String cap = request.getParameter("capacity");
		System.out.println(cap);
		String stat = request.getParameter("stat");
		String labocc = request.getParameter("labocc");
		String month = request.getParameter("labocc");
		String labid = request.getParameter("labid");
		List<Lab> ll = new ArrayList<Lab>();
		ViewDao vd = new ViewDaoImpl();
		Connection con = JdbcConnection.getConnection();
		if(oper != null)
		{
			if(oper.equals("all"))
			{
				ll = vd.viewall(con);
				if(ll == null)
				{
					response.sendRedirect("errorpage.jsp");
				}
				JdbcConnection.closeConnection(con);
				Iterator<Lab> il = ll.iterator();
				pw.println("<html>");
				pw.println("<body bgcolor='Lavender'>");
				pw.println("<h2>All Labs</h2>");
				pw.println("<table border='1'>");
				pw.println("<tr>");
				pw.println("<th>LabID</th>");
				pw.println("<th>Location</th>");
				pw.println("<th>City</th>");
				pw.println("<th>Capacity</th>");
				pw.println("<th>Status</th>");
				pw.println("</tr>");
				while(il.hasNext())
				{
					Lab lab = il.next();
					pw.println("<tr>");
					pw.println("<td>"+lab.getLabid()+"</td>");
					pw.println("<td>"+lab.getLocation()+"</td>");
					pw.println("<td>"+lab.getCity()+"</td>");
					pw.println("<td>"+lab.getCapacity()+"</td>");
					pw.println("<td>"+lab.getStatus()+"</td>");
					pw.println("</tr>");
				}
			}
			else if(oper.equals("search"))
			{
				response.sendRedirect("searchlab.jsp");
			}
			else if(oper.equals("city"))
			{
				response.sendRedirect("CityLab.jsp");
			}
			else if(oper.equals("loc"))
			{
				response.sendRedirect("LocationLab.jsp");
			}
			else if(oper.equals("stat"))
			{
				response.sendRedirect("StatusLab.jsp");
			}
			else if(oper.equals("cap"))
			{
				response.sendRedirect("CapacityLab.jsp");
			}
		}
		else if(id != null)
		{
			int labid2 = Integer.parseInt(id);
			Lab lab = vd.viewsearch(labid2,con);
			if(lab == null)
			{
				response.sendRedirect("errorpage.jsp");
			}
			JdbcConnection.closeConnection(con);
			pw.println("<html>");
			pw.println("<body bgcolor='Lavender'>");
			pw.println("<h2>Lab Details</h2>");
			pw.println("<table border='1'>");
			pw.println("<tr>");
			pw.println("<th>LabID</th>");
			pw.println("<th>Location</th>");
			pw.println("<th>City</th>");
			pw.println("<th>Capacity</th>");
			pw.println("<th>Status</th>");
			pw.println("</tr>");
			pw.println("<tr>");
			pw.println("<td>"+lab.getLabid()+"</td>");
			pw.println("<td>"+lab.getLocation()+"</td>");
			pw.println("<td>"+lab.getCity()+"</td>");
			pw.println("<td>"+lab.getCapacity()+"</td>");
			pw.println("<td>"+lab.getStatus()+"</td>");
			pw.println("</tr>");
		}
		else if(city != null)
		{
			ll = vd.viewcity(city, con);
			if(ll == null)
			{
				response.sendRedirect("errorpage.jsp");
			}
			JdbcConnection.closeConnection(con);
			Iterator<Lab> il = ll.iterator();
			pw.println("<html>");
			pw.println("<body bgcolor='Lavender'>");
			pw.println("<h2>City-Wise Labs</h2>");
			pw.println("<table border='1'>");
			pw.println("<tr>");
			pw.println("<th>LabID</th>");
			pw.println("<th>Location</th>");
			pw.println("<th>City</th>");
			pw.println("<th>Capacity</th>");
			pw.println("<th>Status</th>");
			pw.println("</tr>");
			while(il.hasNext())
			{
				Lab lab = il.next();
				pw.println("<tr>");
				pw.println("<td>"+lab.getLabid()+"</td>");
				pw.println("<td>"+lab.getLocation()+"</td>");
				pw.println("<td>"+lab.getCity()+"</td>");
				pw.println("<td>"+lab.getCapacity()+"</td>");
				pw.println("<td>"+lab.getStatus()+"</td>");
				pw.println("</tr>");
			}
		}
		else if(location != null)
		{
			ll = vd.viewlocation(location, con);
			if(ll == null)
			{
				response.sendRedirect("errorpage.jsp");
			}
			JdbcConnection.closeConnection(con);
			Iterator<Lab> il = ll.iterator();
			pw.println("<html>");
			pw.println("<body bgcolor='Lavender'>");
			pw.println("<h2>Location-Wise Labs</h2>");
			pw.println("<table border='1'>");
			pw.println("<tr>");
			pw.println("<th>LabID</th>");
			pw.println("<th>Location</th>");
			pw.println("<th>City</th>");
			pw.println("<th>Capacity</th>");
			pw.println("<th>Status</th>");
			pw.println("</tr>");
			while(il.hasNext())
			{
				Lab lab = il.next();
				pw.println("<tr>");
				pw.println("<td>"+lab.getLabid()+"</td>");
				pw.println("<td>"+lab.getLocation()+"</td>");
				pw.println("<td>"+lab.getCity()+"</td>");
				pw.println("<td>"+lab.getCapacity()+"</td>");
				pw.println("<td>"+lab.getStatus()+"</td>");
				pw.println("</tr>");
			}
		}
		else if(status != null)
		{
			ll = vd.viewstatus(status, con);
			if(ll == null)
			{
				response.sendRedirect("errorpage.jsp");
			}
			JdbcConnection.closeConnection(con);
			Iterator<Lab> il = ll.iterator();
			pw.println("<html>");
			pw.println("<body>");
			pw.println("<h2>Status-Wise Labs</h2>");
			pw.println("<table border='1'>");
			pw.println("<tr>");
			pw.println("<th>LabID</th>");
			pw.println("<th>Location</th>");
			pw.println("<th>City</th>");
			pw.println("<th>Capacity</th>");
			pw.println("<th>Status</th>");
			pw.println("</tr>");
			while(il.hasNext())
			{
				Lab lab = il.next();
				pw.println("<tr>");
				pw.println("<td>"+lab.getLabid()+"</td>");
				pw.println("<td>"+lab.getLocation()+"</td>");
				pw.println("<td>"+lab.getCity()+"</td>");
				pw.println("<td>"+lab.getCapacity()+"</td>");
				pw.println("<td>"+lab.getStatus()+"</td>");
				pw.println("</tr>");
			}
		}
		else if(cap != null)
		{
			int capacity = Integer.parseInt(cap);
			ll = vd.viewcapacity(capacity, con);
			if(ll == null)
			{
				response.sendRedirect("errorpage.jsp");
			}
			JdbcConnection.closeConnection(con);
			Iterator<Lab> il = ll.iterator();
			pw.println("<html>");
			pw.println("<body>");
			pw.println("<h2>Capacity-Wise Labs</h2>");
			pw.println("<table border='1'>");
			pw.println("<tr>");
			pw.println("<th>LabID</th>");
			pw.println("<th>Location</th>");
			pw.println("<th>City</th>");
			pw.println("<th>Capacity</th>");
			pw.println("<th>Status</th>");
			pw.println("</tr>");
			while(il.hasNext())
			{
				Lab lab = il.next();
				pw.println("<tr>");
				pw.println("<td>"+lab.getLabid()+"</td>");
				pw.println("<td>"+lab.getLocation()+"</td>");
				pw.println("<td>"+lab.getCity()+"</td>");
				pw.println("<td>"+lab.getCapacity()+"</td>");
				pw.println("<td>"+lab.getStatus()+"</td>");
				pw.println("</tr>");
			}
		}
		else if(stat != null)
		{
			if(stat.equals("logout"))
			{
				HttpSession hs = request.getSession();
				hs.invalidate();
			}
		}
		else if(labocc != null)
		{
			if(labocc.equals("yes"))
			{
				response.sendRedirect("laboccupancy.jsp");
			}
			else
			{
				int labid1 = Integer.parseInt(labid);
				int occupancy = vd.getlaboccupancy(con, month, labid1);
				pw.println("Lab Occupancy for lab "+labid1 +" is "+occupancy+"%");
			}
		}
		else
		{
			response.sendRedirect("laboccupancy.jsp");
		}
	}
}
