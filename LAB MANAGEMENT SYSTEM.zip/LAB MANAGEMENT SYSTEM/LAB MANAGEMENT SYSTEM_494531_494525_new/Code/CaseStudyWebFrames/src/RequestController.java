

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import classes.Request;
import dao.RequestDao;
import dao.RequestDaoImpl;

import utility.JdbcConnection;

public class RequestController extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    public RequestController() 
    {
        super();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String role = request.getParameter("role");
		response.setContentType("text/html");
		String id = request.getParameter("id");
		String auth = request.getParameter("auth");
		String op = request.getParameter("op");
		System.out.println(id);
		System.out.println(auth);
		PrintWriter pw = response.getWriter();
		Connection con = null;
		con = JdbcConnection.getConnection();
		List<Request> lr = new ArrayList<Request>();
		RequestDao rd = new RequestDaoImpl();
		Iterator<Request> ir = lr.iterator();
		if(role != null)
		{
			lr = rd.viewreq(con, role);
			if(lr != null)
			{
				JdbcConnection.closeConnection(con);
				ir = lr.iterator();
				if(role.equals("OTH"))
				{
					System.out.println("in if");
					pw.println("<html>");
					pw.println("<body bgcolor='Lavender'>");
					pw.println("<table border='1'>");
					pw.println("<tr>");
					pw.println("<th>Request ID</th>");
					pw.println("<th>Booking ID</th>");
					pw.println("<th>Request Status</th>");
					pw.println("<th>LO ID</th>");
					pw.println("<th>Lab ID</th>");
					pw.println("<th>Location</th>");
					pw.println("<th>City</th>");
					pw.println("<th>Response</th>");
					pw.println("</tr>");
					while(ir.hasNext())
					{
						System.out.println("in itr");
						Request r = ir.next();
						System.out.println(r);
						pw.println("<tr>");
						pw.println("<td>"+r.getRequestid()+"</td>");
						pw.println("<td>"+r.getBookingid()+"</td>");
						pw.println("<td>"+r.getReqstatus()+"</td>");
						pw.println("<td>"+r.getLoid()+"</td>");
						pw.println("<td>"+r.getLabid()+"</td>");
						pw.println("<td>"+r.getLocation()+"</td>");
						pw.println("<td>"+r.getCity()+"</td>");
						pw.println("<td><form action='RequestController'>Accept<input type='radio' name='auth' value='Accepted'>Reject<input type='radio' name='auth' value='Rejected'><input type='hidden' name='id' value='"+r.getRequestid()+"'><input type='submit' value='done'><input type='reset' value='clear'></form></td>");
						pw.println("</tr>");
					}
					pw.println("</table>");
					pw.println("</body>");
					pw.println("</html>");
				}
				else if(role.equals("OTM"))
				{
					System.out.println("in if");
					pw.println("<html>");
					pw.println("<body bgcolor='Lavender'>");
					pw.println("<table border='1'>");
					pw.println("<tr>");
					pw.println("<th>Request ID</th>");
					pw.println("<th>Booking ID</th>");
					pw.println("<th>Request Status</th>");
					pw.println("<th>LO ID</th>");
					pw.println("<th>Lab ID</th>");
					pw.println("<th>Location</th>");
					pw.println("<th>City</th>");
					pw.println("<th>Response</th>");
					pw.println("</tr>");
					while(ir.hasNext())
					{
						System.out.println("in itr");
						Request r = ir.next();
						System.out.println(r);
						pw.println("<tr>");
						pw.println("<td>"+r.getRequestid()+"</td>");
						pw.println("<td>"+r.getBookingid()+"</td>");
						pw.println("<td>"+r.getReqstatus()+"</td>");
						pw.println("<td>"+r.getLoid()+"</td>");
						pw.println("<td>"+r.getLabid()+"</td>");
						pw.println("<td>"+r.getLocation()+"</td>");
						pw.println("<td>"+r.getCity()+"</td>");
						pw.println("<td><form action='RequestController'>Accept<input type='radio' name='auth' value='Approved'>Reject<input type='radio' name='auth' value='Rejected'>Validate<input type='radio' name='auth' value='in process'><input type='hidden' name='id' value='"+r.getRequestid()+"'><input type='submit' value='done'><input type='reset' value='clear'></form></td>");
						pw.println("</tr>");
					}
					pw.println("</table>");
					pw.println("</body>");
					pw.println("</html>");
				}
			}
			else
			{
				response.sendRedirect("errorpage.jsp");
			}
		}
		else if(id != null && auth != null)
		{
			if(!auth.equals("in process"))
			{
				System.out.println("in else");
				int rid = Integer.parseInt(id);
				boolean flag = rd.updateStatus(rid, con, auth);
				JdbcConnection.closeConnection(con);
				if(flag)
				{
					pw.println("Lab Status Updated");
				}
				else 
				{
					response.sendRedirect("errorpage.jsp");
				}
			}
			else if (auth.equals("in process"))
			{
				int rid = Integer.parseInt(id);
				boolean verify = rd.verificationupdate(rid, con);
				JdbcConnection.closeConnection(con);
				if(verify)
				{
					pw.println("Verification Sent");
				}
				else
				{
					response.sendRedirect("errorpage.jsp");
				}
			}
		}
		else if(op != null)
		{
			HttpSession hs = request.getSession();
			String loname = (String) hs.getAttribute("username");
			lr = rd.myreq(con, loname);
			if(lr == null)
			{
				response.sendRedirect("errorpage.jsp");
			}
			ir = lr.iterator();
			pw.println("<html>");
			pw.println("<body bgcolor='Lavender'>");
			pw.println("<table>");
			pw.println("<tr>");
			pw.println("<th>Request ID</th>");
			pw.println("<th>Booking ID</th>");
			pw.println("<th>Request Status</th>");
			pw.println("<th>LO ID</th>");
			pw.println("<th>Lab ID</th>");
			pw.println("<th>Location</th>");
			pw.println("<th>City</th>");
			pw.println("<th>Response</th>");
			pw.println("</tr>");
			while(ir.hasNext())
			{
				System.out.println("in itr");
				Request r = ir.next();
				System.out.println(r);
				pw.println("<tr>");
				pw.println("<td>"+r.getRequestid()+"</td>");
				pw.println("<td>"+r.getBookingid()+"</td>");
				pw.println("<td>"+r.getReqstatus()+"</td>");
				pw.println("<td>"+r.getLoid()+"</td>");
				pw.println("<td>"+r.getLabid()+"</td>");
				pw.println("<td>"+r.getLocation()+"</td>");
				pw.println("<td>"+r.getCity()+"</td>");
			}
			pw.println("</table>");
			pw.println("</body>");
			pw.println("</html>");
		}
	}
}

