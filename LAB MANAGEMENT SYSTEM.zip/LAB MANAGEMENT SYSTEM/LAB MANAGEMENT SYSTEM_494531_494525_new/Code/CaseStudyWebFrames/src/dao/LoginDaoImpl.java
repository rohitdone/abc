package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class LoginDaoImpl implements LoginDao
{
	public String getRole(String username, String password,Connection con) 
	{
		PreparedStatement pst = null;
		ResultSet rs = null;
		boolean flag = false;
		String role = "a";
		String query = "select role from login where username=? and password=?";
		try 
		{
			pst = con.prepareStatement(query);
			pst.setString(1, username);
			pst.setString(2, password);
			rs = pst.executeQuery();
			while(rs.next())
			{
				flag = true;
				role = rs.getString(1);
			}
		}
		catch (SQLException e) 
		{
			return null;
		}
		if(flag == true)
		{
			return role;
		}
		else
		{
			return "abc";
		}
	}
}
