package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import utility.JdbcConnection;

import classes.Lab;

public class ViewDaoImpl implements ViewDao {

	@Override
	public List<Lab> viewall(Connection con) 
	{
		ResultSet rs = null;
		PreparedStatement pst = null;
		List<Lab> ll = new ArrayList<Lab>();
		con = JdbcConnection.getConnection();
		String query = "select labid,loc.name,ci.name,status,capacity from city ci,location loc,lab l,condition c where l.conditionid = c.conditionid and loc.locationid = l.locationid and ci.cityid = loc.cityid";
		try 
		{
			pst = con.prepareStatement(query);
			rs = pst.executeQuery();
			while(rs.next())
			{
				int id = rs.getInt(1);
				String location = rs.getString(2);
				String city = rs.getString(3);
				String status = rs.getString(4);
				int capacity = rs.getInt(5);
				Lab l = new Lab(id, location, city, status, capacity);
				ll.add(l);
			}
			return ll;
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Lab viewsearch(int labid, Connection con) 
	{
		ResultSet rs = null;
		PreparedStatement pst = null;
		Lab l = new Lab();
		con = JdbcConnection.getConnection();
		String query = "select labid,loc.name,ci.name,status,capacity from city ci,location loc,lab l,condition c where l.conditionid = c.conditionid and loc.locationid = l.locationid and ci.cityid = loc.cityid and l.labid = ?";
		try 
		{
			pst = con.prepareStatement(query);
			pst.setInt(1, labid);
			rs = pst.executeQuery();
			while(rs.next())
			{
				l.setLabid(rs.getInt(1));
				l.setLocation(rs.getString(2));
				l.setCity(rs.getString(3));
				l.setStatus(rs.getString(4));
				l.setCapacity(rs.getInt(5));
			}
			return l;
		} 
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<Lab> viewcity(String city, Connection con)
	{
		PreparedStatement pst = null;
		ResultSet rs = null;
		List<Lab> ll = new ArrayList<Lab>();
		String query = "select labid,loc.name,ci.name,status,capacity from city ci,location loc,lab l,condition c where l.conditionid = c.conditionid and loc.locationid = l.locationid and ci.cityid = loc.cityid and ci.name = ?";
		try
		{
			pst = con.prepareStatement(query);
			pst.setString(1, city);
			rs = pst.executeQuery();
			while(rs.next())
			{
				int id = rs.getInt(1);
				String location = rs.getString(2);
				String city1 = rs.getString(3);
				String status = rs.getString(4);
				int capacity = rs.getInt(5);
				Lab l = new Lab(id, location, city1, status, capacity);
				ll.add(l);
			}
			return ll;
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<Lab> viewlocation(String location, Connection con) 
	{
		PreparedStatement pst = null;
		ResultSet rs = null;
		List<Lab> ll = new ArrayList<Lab>();
		String query = "select labid,loc.name,ci.name,status,capacity from city ci,location loc,lab l,condition c where l.conditionid = c.conditionid and loc.locationid = l.locationid and ci.cityid = loc.cityid and loc.name = ?";
		try
		{
			pst = con.prepareStatement(query);
			pst.setString(1, location);
			rs = pst.executeQuery();
			while(rs.next())
			{
				int id = rs.getInt(1);
				String location1 = rs.getString(2);
				String city1 = rs.getString(3);
				String status = rs.getString(4);
				int capacity = rs.getInt(5);
				Lab l = new Lab(id, location1, city1, status, capacity);
				ll.add(l);			
			}
			return ll;
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<Lab> viewstatus(String status, Connection con)
	{
		PreparedStatement pst = null;
		ResultSet rs = null;
		List<Lab> ll = new ArrayList<Lab>();
		String query = "select labid,loc.name,ci.name,status,capacity from city ci,location loc,lab l,condition c where l.conditionid = c.conditionid and loc.locationid = l.locationid and ci.cityid = loc.cityid and status = ?";
		try
		{
			pst = con.prepareStatement(query);
			pst.setString(1, status);
			rs = pst.executeQuery();
			while(rs.next())
			{
				int id = rs.getInt(1);
				String location = rs.getString(2);
				String city1 = rs.getString(3);
				String status1 = rs.getString(4);
				int capacity = rs.getInt(5);
				Lab l = new Lab(id, location, city1, status1, capacity);
				ll.add(l);
			}
			return ll;
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<Lab> viewcapacity(int capacity, Connection con) 
	{
		PreparedStatement pst = null;
		ResultSet rs = null;
		List<Lab> ll = new ArrayList<Lab>();
		String query = "select labid,loc.name,ci.name,status,capacity from city ci,location loc,lab l,condition c where l.conditionid = c.conditionid and loc.locationid = l.locationid and ci.cityid = loc.cityid and capacity >= ?";
		try
		{
			pst = con.prepareStatement(query);
			pst.setInt(1, capacity);
			rs = pst.executeQuery();
			while(rs.next())
			{
				int id = rs.getInt(1);
				String location = rs.getString(2);
				String city1 = rs.getString(3);
				String status = rs.getString(4);
				int capacity1 = rs.getInt(5);
				Lab l = new Lab(id, location, city1, status, capacity1);
				ll.add(l);
			}
			return ll;
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public int getlaboccupancy(Connection con, String month, int labid) 
	{
		PreparedStatement pst = null;
		int bday = 0;
		int rday = 0;
		int tday = 0;
		int occupancy = 0;
		ResultSet rs = null;
		String query = "select booking_date,release_date from lo_lab where labid = ? and to_char(booking_date,'Mon') = ? order by booking_date";
		try 
		{
			pst = con.prepareStatement(query);
			pst.setInt(1, labid);
			pst.setString(2, month);
			rs = pst.executeQuery();
			while(rs.next())
			{
				Date d1 = rs.getDate(1);
				Date d2 = rs.getDate(2);
				rday = d2.getDate();
				if(d2.getDate() <= d1.getDate())
				{
					if(month.equals("Jan") || month.equals("Mar")|| month.equals("May")||month.equals("Jul")||month.equals("Aug")||month.equals("Oct")||month.equals("Dec"))
					{
						rday = 31;
						tday = 31;
					}
					else if(month.equals("Apr") || month.equals("Jun")|| month.equals("Sep")||month.equals("Nov"))
					{
						rday = 30;
						tday = 30;
					}
					else if(month.equals("Feb"))
					{
						rday = 28;
						tday = 28;
					}
				}
				else if(d2.getMonth() < d1.getMonth())
				{
					if(month.equals("Jan") || month.equals("Mar")|| month.equals("May")||month.equals("Jul")||month.equals("Aug")||month.equals("Oct")||month.equals("Dec"))
					{
						rday = 31;
						tday = 31;
					}
					else if(month.equals("Apr") || month.equals("Jun")|| month.equals("Sep")||month.equals("Nov"))
					{
						rday = 30;
						tday = 30;
					}
					else if(month.equals("Feb"))
					{
						rday = 28;
						tday = 28;
					}
				}
				else if (d2.getYear() >= d1.getYear()) 
				{
					if(month.equals("Jan") || month.equals("Mar")|| month.equals("May")||month.equals("Jul")||month.equals("Aug")||month.equals("Oct")||month.equals("Dec"))
					{
						rday = 31;
						tday = 31;
					}
					else if(month.equals("Apr") || month.equals("Jun")|| month.equals("Sep")||month.equals("Nov"))
					{
						rday = 30;
						tday = 30;
					}
					else if(month.equals("Feb"))
					{
						rday = 28;
						tday = 28;
					}
				}
				bday = d1.getDate();
				System.out.println("rel"+rday);
				System.out.println("book"+bday);
				occupancy = occupancy + (rday - bday); 
				System.out.println("occ"+occupancy);
			}
			occupancy = occupancy * 100;
			System.out.println("occ"+occupancy);
			occupancy = occupancy/tday;
			System.out.println("occ%"+occupancy);
			return occupancy;
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		return 0;
	}

}
