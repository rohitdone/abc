package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


import classes.Request;

public class RequestDaoImpl implements RequestDao
{

	@Override
	public List<Request> viewreq(Connection con, String role) 
	{
		PreparedStatement pst = null;
		ResultSet rs = null;
		List<Request> lr = new ArrayList<Request>();
		String query = "select requestid,l.bookingid,reqstatus,loid,l.labid,loc.name,c.name from lo_lab l, request r,location loc,city c,lab la where r.bookingid = l.bookingid and l.labid = la.labid and la.locationid = loc.locationid and loc.cityid = c.cityid and reqstatus = ? and r.role = ?";
		try 
		{
			pst = con.prepareStatement(query);
			pst.setString(1, "in process");
			pst.setString(2, role);
			rs = pst.executeQuery();
			while(rs.next())
			{
				int requestid = rs.getInt(1);
				int bookingid = rs.getInt(2);
				String reqstatus = rs.getString(3);
				int loid = rs.getInt(4);
				int labid = rs.getInt(5);
				String location = rs.getString(6);
				String city = rs.getString(7);
				Request r = new Request(requestid, bookingid, reqstatus, role, loid, labid, location, city);
				lr.add(r);
			}
			return lr;
		} 
		catch (SQLException e) 
		{	
			return null;
		}
	}

	@Override
	public boolean updateStatus(int id, Connection con, String auth)
	{
		System.out.println("in fun");
		PreparedStatement pst = null;
		PreparedStatement pst1 = null;
		PreparedStatement pst0 = null;
		ResultSet rs = null;
		String query = "update request set reqstatus = ? where requestid = ?";
		String query0 = "select labid from request r, lo_lab l where r.bookingid = l.bookingid and requestid = ?";
		String query1 = "update lab set status = ? where labid = ?";
		
		try 
		{
			pst = con.prepareStatement(query);
			pst.setString(1, auth);
			pst.setInt(2, id);
			pst.executeUpdate();
			System.out.println("statement exec");
		}
		catch (SQLException e) 
		{
			return false;
		}
		try
		{
			pst0 = con.prepareStatement(query0);
			pst0.setInt(1, id);
			rs = pst0.executeQuery();
			while(rs.next())
			{
				if(auth.equals("Approved"))
				{
					auth = "Booked";
				}
				else
				{
					auth = "Available";
				}
				int labid = rs.getInt(1);
				pst1 = con.prepareStatement(query1);
				pst1.setString(1, auth);
				pst1.setInt(2, labid);
				pst1.executeUpdate();
				return true;
			}
		} 
		catch (SQLException e)
		{
			return false;
		}
		return false;
	}

	@Override
	public boolean verificationupdate(int id, Connection con)
	{
		PreparedStatement pst = null;
		String query = "update request set role = ? where requestid = ?";
		try 
		{
			pst = con.prepareStatement(query);
			pst.setString(1, "OTH");
			pst.setInt(2, id);
			pst.executeUpdate();
			return true;
		} 
		catch (SQLException e) 
		{
			return false;
		}
	}

	@Override
	public boolean book(int rid, int bid, int labid, int loid, Date bdate, Connection con) 
	{
		PreparedStatement pst = null;
		PreparedStatement pst1 = null;
		PreparedStatement pst2 = null;
		String query = "insert into lo_lab values(?,?,?,?,?)";
		String query1 = "insert into request values(?,?,?,?)";
		try
		{
			System.out.println("in book");
			Date rdate = new Date(31-12-2049);
			pst = con.prepareStatement(query);
			pst1 = con.prepareStatement(query1);
			pst.setInt(1, bid);
			pst.setInt(2, loid);
			pst.setInt(3, labid);
			pst.setDate(4, bdate);
			pst.setDate(5, rdate);
			pst.executeUpdate();
			pst1 = con.prepareStatement(query1);
			pst1.setInt(1, rid);
			pst1.setInt(2, bid);
			pst1.setString(3, "in process");
			pst1.setString(4, "OTM");
			pst1.executeUpdate();
			return true;
		} 
		catch (SQLException e) 
		{
			return false;
		}
	}

	@Override
	public boolean release(int rid, int labid, int loid, Date rd, Connection con)
	{
		PreparedStatement pst = null;
		PreparedStatement pst1 = null;
		String query ="update lo_lab set release_date = ? where labid = ? and loid = ?";
		String query1 = "insert into request(requestid,reqstatus,role) values(?,?,?)";
		try 
		{
			System.out.println("in release try");
			pst = con.prepareStatement(query);
			pst.setDate(1, rd);
			pst.setInt(2, labid);
			pst.setInt(3, loid);
			int i = pst.executeUpdate();
			System.out.println(i);
			
		} 
		catch (SQLException e)
		{
			return false;
		}
		try
		{
			pst1 = con.prepareStatement(query1);
			pst1.setInt(1, rid);
			pst1.setString(2, "in process");
			pst1.setString(3, "OTM");
			int j = pst.executeUpdate();
			System.out.println(j);
			return true;
		}
		catch (SQLException e) 
		{
			return false;
		}
		
	}

	@Override
	public List<Request> myreq(Connection con, String loname)
	{
		List<Request> lr = new ArrayList<Request>();
		PreparedStatement pst0 = null;
		PreparedStatement pst1 = null;
		ResultSet rs0 = null;
		ResultSet rs1 = null;
		int loid = 0;
		String query0 = "select * from lo where name = ?";
		String query1 = "select requestid,l.bookingid,reqstatus,loid,l.labid,loc.name,c.name,role from lo_lab l, request r,location loc,city c,lab la where r.bookingid = l.bookingid and l.labid = la.labid and la.locationid = loc.locationid and loc.cityid = c.cityid and loid = ?";
		try 
		{
			pst0 = con.prepareStatement(query0);
			pst0.setString(1, loname);
			rs0 = pst0.executeQuery();
			while(rs0.next())
			{
				loid = rs0.getInt(1);
			}
			pst1 = con.prepareStatement(query1);
			pst1.setInt(1, loid);
			rs1 = pst1.executeQuery();
			while(rs1.next())
			{
				int requestid = rs1.getInt(1);
				int bookingid = rs1.getInt(2);
				String reqstatus = rs1.getString(3);
				int loid1 = rs1.getInt(4);
				int labid = rs1.getInt(5);
				String location = rs1.getString(6);
				String city = rs1.getString(7);
				String role = rs1.getString(8);
				Request r = new Request(requestid, bookingid, reqstatus, role, loid1, labid, location, city);
				lr.add(r);
			}
			return lr;
		}
		catch (SQLException e) 
		{
			return null;
		}
	}

}
