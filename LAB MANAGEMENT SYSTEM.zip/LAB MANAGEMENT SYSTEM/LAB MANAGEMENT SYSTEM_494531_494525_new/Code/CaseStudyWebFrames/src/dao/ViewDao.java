package dao;

import java.sql.Connection;
import java.util.List;

import classes.Lab;

public interface ViewDao 
{
	List<Lab> viewall(Connection con);
	Lab viewsearch(int labid, Connection con);
	List<Lab> viewcity(String city, Connection con);
	List<Lab> viewlocation(String location, Connection con);
	List<Lab> viewstatus(String status, Connection con);
	List<Lab> viewcapacity(int capacity, Connection con);
	int getlaboccupancy(Connection con, String month, int labid);
}
