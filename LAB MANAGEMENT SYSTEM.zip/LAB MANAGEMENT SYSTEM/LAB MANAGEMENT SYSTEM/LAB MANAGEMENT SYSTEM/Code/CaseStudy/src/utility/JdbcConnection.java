package utility;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class JdbcConnection 
{
	public static Connection getConnection()
	{
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		Connection con=null;
		try 
		{
			Context context = new InitialContext();
			DataSource datasource = (DataSource) context.lookup("alex");
			con = datasource.getConnection();
			if(con != null)
			{
				System.out.println("Connected");
			}
		} 
		catch (SQLException e)
		{
			e.printStackTrace();
		} 
		catch (NamingException e) 
		{
			e.printStackTrace();
		}
		return con;
	}
	
	public static void closeConnection(Connection con)
	{
		try 
		{
			con.close();
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
	}
}
