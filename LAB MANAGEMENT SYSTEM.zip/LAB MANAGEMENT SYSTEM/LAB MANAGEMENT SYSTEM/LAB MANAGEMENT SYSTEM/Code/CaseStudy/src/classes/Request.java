package classes;

public class Request 
{
	private int requestid;
	private int bookingid;
	private String reqstatus;
	private String role;
	private int loid;
	private int labid;
	private String location;
	private String city;
	public int getRequestid() {
		return requestid;
	}
	public void setRequestid(int requestid) {
		this.requestid = requestid;
	}
	public int getBookingid() {
		return bookingid;
	}
	public void setBookingid(int bookingid) {
		this.bookingid = bookingid;
	}
	public String getReqstatus() {
		return reqstatus;
	}
	public void setReqstatus(String reqstatus) {
		this.reqstatus = reqstatus;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public int getLoid() {
		return loid;
	}
	public void setLoid(int loid) {
		this.loid = loid;
	}
	public int getLabid() {
		return labid;
	}
	public void setLabid(int labid) {
		this.labid = labid;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public Request(int requestid, int bookingid, String reqstatus, String role,
			int loid, int labid, String location, String city) {
		super();
		this.requestid = requestid;
		this.bookingid = bookingid;
		this.reqstatus = reqstatus;
		this.role = role;
		this.loid = loid;
		this.labid = labid;
		this.location = location;
		this.city = city;
	}
	public Request() {
		super();
	}
	@Override
	public String toString() {
		return "Request [requestid=" + requestid + ", bookingid=" + bookingid
				+ ", reqstatus=" + reqstatus + ", role=" + role + ", loid="
				+ loid + ", labid=" + labid + ", location=" + location
				+ ", city=" + city + "]";
	}
	
	
}
