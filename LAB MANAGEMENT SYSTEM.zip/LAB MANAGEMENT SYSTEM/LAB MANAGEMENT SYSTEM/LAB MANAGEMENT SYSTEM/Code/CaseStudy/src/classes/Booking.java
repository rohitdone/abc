package classes;

import java.sql.Date;

public class Booking 
{
	private int bookingid;
	private int labid;
	private int loid;
	private Date bookingdate;
	private Date releasedate;
	public int getBookingid() {
		return bookingid;
	}
	public void setBookingid(int bookingid) {
		this.bookingid = bookingid;
	}
	public int getLabid() {
		return labid;
	}
	public void setLabid(int labid) {
		this.labid = labid;
	}
	public int getLoid() {
		return loid;
	}
	public void setLoid(int loid) {
		this.loid = loid;
	}
	public Date getBookingdate() {
		return bookingdate;
	}
	public void setBookingdate(Date bookingdate) {
		this.bookingdate = bookingdate;
	}
	public Date getReleasedate() {
		return releasedate;
	}
	public void setReleasedate(Date releasedate) {
		this.releasedate = releasedate;
	}
	public Booking(int bookingid, int labid, int loid, Date bookingdate,
			Date releasedate) {
		super();
		this.bookingid = bookingid;
		this.labid = labid;
		this.loid = loid;
		this.bookingdate = bookingdate;
		this.releasedate = releasedate;
	}
	public Booking() {
		super();
	}
	@Override
	public String toString() {
		return "Booking [bookingid=" + bookingid + ", labid=" + labid
				+ ", loid=" + loid + ", bookingdate=" + bookingdate
				+ ", releasedate=" + releasedate + "]";
	}
	
	
}
