package dao;

import java.sql.Connection;
import java.sql.Date;
import java.util.List;

import classes.Request;

public interface RequestDao 
{
	List<Request> viewreq(Connection con,String role);
	boolean updateStatus(int id, Connection con, String auth);
	boolean verificationupdate(int id, Connection con);
	boolean book(int rid, int bid, int labid, int loid, Date sd, Connection con);
	boolean release(int rid, int labid, int loid, Date rd, Connection con);
	List<Request> myreq(Connection con,String loname);
}
