package dao;

import java.sql.Connection;

public interface LoginDao
{
	String getRole(String username,String password,Connection con);
}
