package dao;

import java.sql.Connection;

public interface OperationsDao
{
	boolean removelab(int labid,Connection con);
	boolean addlab(int id, int locationid, int conditionid, int capacity, Connection con);
	boolean changestat(int labid, String status, Connection con);
}
