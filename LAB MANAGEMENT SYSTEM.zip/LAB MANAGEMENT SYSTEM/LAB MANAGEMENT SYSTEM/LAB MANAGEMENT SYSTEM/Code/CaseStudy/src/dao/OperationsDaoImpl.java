package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class OperationsDaoImpl implements OperationsDao
{
	@Override
	public boolean removelab(int labid, Connection con)
	{
		PreparedStatement pst = null;
		String query = "delete from lab where labid = ?";
		try 
		{
			pst = con.prepareStatement(query);
			pst.setInt(1, labid);
			pst.executeUpdate();
			return true;
		}
		catch (SQLException e)
		{
			return false;
		}
	}

	@Override
	public boolean addlab(int id, int locationid, int conditionid, int capacity, Connection con) 
	{
		PreparedStatement pst = null;
		System.out.println(id);
		System.out.println(locationid);
		System.out.println(conditionid);
		System.out.println(capacity);
		String query = "insert into lab values(?,?,?,?,?)";
		try
		{
			pst = con.prepareStatement(query);
			pst.setInt(1, id);
			pst.setString(2, "available");
			pst.setInt(3, capacity);
			pst.setInt(4, conditionid);
			pst.setInt(5, locationid);
			pst.executeUpdate();
			
			return true;
		}
		catch (SQLException e) 
		{
			return false;
		}
		
	}

	@Override
	public boolean changestat(int labid, String status, Connection con)
	{
		PreparedStatement pst = null;
		String query = "update lab set status = ? where labid = ?";
		try 
		{
			pst = con.prepareStatement(query);
			pst.setString(1, status);
			pst.setInt(2, labid);
			pst.executeUpdate();
			return true;
		}
		catch (SQLException e) 
		{
			return false;
		}
	}
}
