

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import utility.JdbcConnection;

import dao.RequestDao;
import dao.RequestDaoImpl;


public class BookingController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public BookingController() 
    {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		String op = request.getParameter("op");
		//String id = request.getParameter("id");
		String labid = request.getParameter("labid");
		String bdate = request.getParameter("bdate");
		String rdate = request.getParameter("rdate");
		RequestDao rd = new RequestDaoImpl();
		Connection con = JdbcConnection.getConnection();
		HttpSession hs = request.getSession();
		String username = (String) hs.getAttribute("username");
		System.out.println("username :"+username);
		String rellabid = request.getParameter("rellabid");
		String relloid = request.getParameter("relloid");
		CallableStatement cst = null;
		CallableStatement cst1 = null;
		
		String call1 = "{call getrequestid(?)}";
		try 
		{
			
			cst1 = con.prepareCall(call1);
			cst1.registerOutParameter(1, Types.INTEGER);
			cst1.execute();
			int reqid = cst1.getInt(1);
			if(op != null)
			{
				if(op.equals("book"))
				{
					response.sendRedirect("booking.jsp");
				}
				else if(op.equals("rel"))
				{
					response.sendRedirect("release.jsp");
				}
			}
			else if(labid != null && bdate != null)
			{
				System.out.println("in elsif");
				//int bid = Integer.parseInt(id);
				int laid = Integer.parseInt(labid);
				int lid = 0;
				PreparedStatement pst = null;
				SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
				ResultSet rs = null;
				String query = "select * from lo where name = ?";
				String call = "{call getbookingid(?)}";
				try 
				{
					cst = con.prepareCall(call);
					cst.registerOutParameter(1, Types.INTEGER);
					cst.execute();
					int bookid = cst.getInt(1);
					System.out.println(bookid);
					System.out.println(reqid);
					pst = con.prepareStatement(query);
					pst.setString(1, username);
					rs = pst.executeQuery();
					while(rs.next())
					{
						lid = rs.getInt(1);
					}
					java.util.Date jd = sdf.parse(bdate);
					java.sql.Date sd = new java.sql.Date(jd.getTime());
					boolean flag = rd.book(reqid,bookid, laid, lid, sd, con);
					JdbcConnection.closeConnection(con);
					if(flag)
					{
						pw.println("Requested");
						pw.println("Booking ID : "+bookid);
					}
					else
					{
						response.sendRedirect("errorpage.jsp");
					}
				} 
				catch (ParseException e) 
				{
					response.sendRedirect("errorpage.jsp");
				} 
				catch (SQLException e) 
				{
					response.sendRedirect("errorpage.jsp");
				}
			}
			else if(rdate != null)
			{
				int rellabid1 = Integer.parseInt(rellabid);
				int relloid1 = Integer.parseInt(relloid);
				SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
				try 
				{
					java.util.Date jd = sdf.parse(rdate);
					java.sql.Date sd = new java.sql.Date(jd.getTime());
					System.out.println("in release");
					boolean flag = rd.release(reqid,rellabid1,relloid1, sd, con);
					JdbcConnection.closeConnection(con);
					if(flag)
					{
						pw.println("Released");
					}
					else
					{
						response.sendRedirect("errorpage.jsp");
					}
				} 
				catch (ParseException e)
				{
					response.sendRedirect("errorpage.jsp");
				}
			}
		} 
		catch (SQLException e1)
		{
			response.sendRedirect("errorpage.jsp");
		}
		
		
	}
}
