

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import utility.JdbcConnection;

import dao.LoginDao;
import dao.LoginDaoImpl;

public class LoginController extends HttpServlet
{
	private static final long serialVersionUID = 1L;
    public LoginController() 
    {
        super();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		String uname = request.getParameter("username");
		String pass = request.getParameter("password");
		Connection con = JdbcConnection.getConnection();
		HttpSession hs = request.getSession();
		hs.setAttribute("username", uname);
		String username = (String) hs.getAttribute("username");
		System.out.println(username);
		LoginDao ld = new LoginDaoImpl();
		String role = "a";
		role = ld.getRole(uname, pass,con);
		System.out.println(role);
		String stat = request.getParameter("stat");
		JdbcConnection.closeConnection(con);
		if(!role.equals("abc"))
		{
			if(role.equals("OTH"))
			{
				response.sendRedirect("OthHome.jsp");
			}
			else
			{
				if(role.equals("OTM"))
				{
					response.sendRedirect("OtmHome.jsp");
				}
				else
				{
					response.sendRedirect("LoHome.jsp");
				}
			}
		}
		else if(role.equals("abc"))
		{
			request.getRequestDispatcher("Home.jsp").include(request, response);
			pw.println("Wrong Username/Password");
		}
		if(stat != null)
		{
			hs.invalidate();
			request.getRequestDispatcher("Home.jsp").forward(request, response);
		}
	}
}
